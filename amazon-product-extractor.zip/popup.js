document.addEventListener('DOMContentLoaded', function() {
    const extractBtn = document.getElementById('extractBtn');
    const status = document.getElementById('status');
    const productInfo = document.getElementById('productInfo');
    const openCalculatorBtn = document.getElementById('openCalculator');
    const copyBtn = document.getElementById('copyBtn');
    
    // 设置插件安装标识 - 使用chrome.storage而不是localStorage
    chrome.storage.local.set({ 'amazonExtensionInstalled': 'true' });
    
    // 显示状态消息
    function showStatus(message, type = 'info') {
        status.textContent = message;
        status.className = `status ${type}`;
        status.style.display = 'block';
        
        if (type === 'success' || type === 'error') {
            setTimeout(() => {
                status.style.display = 'none';
            }, 3000);
        }
    }
    
    // 显示产品信息
    function showProductInfo(data) {
        document.getElementById('productTitle').textContent = data.title || '未找到';
        document.getElementById('productWeight').textContent = data.weight || '未找到';
        document.getElementById('productDimensions').textContent = data.dimensions || '未找到';
        document.getElementById('productAsin').textContent = data.asin || '未找到';
        
        const productLink = document.getElementById('productLink');
        if (data.url) {
            productLink.href = data.url;
            productLink.textContent = data.url.length > 40 ? data.url.substring(0, 40) + '...' : data.url;
        } else {
            productLink.textContent = '未找到';
            productLink.removeAttribute('href');
        }
        
        document.getElementById('productPrice').textContent = data.price || '未找到';
        
        productInfo.style.display = 'block';
        openCalculatorBtn.style.display = 'block';
        copyBtn.style.display = 'block';
    }
    
    // 复制产品信息到剪贴板
    // 复制产品信息到剪贴板
    function copyProductInfo(data) {
        const copyText = `产品名称: ${data.title || '未找到'}
重量: ${data.weight || '未找到'}
尺寸: ${data.dimensions || '未找到'}
ASIN: ${data.asin || '未找到'}
链接: ${data.url || '未找到'}
价格: ${data.price || '未找到'}`;
        
        navigator.clipboard.writeText(copyText).then(() => {
            // 复制成功，更新按钮状态
            copyBtn.textContent = '✓ 复制成功';
            copyBtn.classList.add('copied');
            
            // 3秒后恢复按钮状态
            setTimeout(() => {
                copyBtn.textContent = '📋 复制产品信息';
                copyBtn.classList.remove('copied');
            }, 3000);
        }).catch(err => {
            console.error('复制失败:', err);
            // 只在控制台显示错误，不显示状态提示
        });
    }
    
    // 提取产品信息
    extractBtn.addEventListener('click', async function() {
        extractBtn.disabled = true;
        extractBtn.textContent = '提取中...';
        showStatus('正在提取产品信息...', 'info');
        
        try {
            // 获取当前活动标签页
            const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
            
            // 检查是否在Amazon页面
            if (!tab.url.includes('amazon.com')) {
                throw new Error('请在Amazon.com产品页面使用此扩展');
            }
            
            // 发送消息到内容脚本
            const response = await chrome.tabs.sendMessage(tab.id, { action: 'extractProduct' });
            
            if (response.success) {
                showStatus(response.message, 'success');
                showProductInfo(response.data);
                
                // 存储数据供计算器使用
                await chrome.storage.local.set({ 
                    amazonProductData: response.data,
                    extractTime: Date.now()
                });
                
                // 存储到chrome.storage供网页访问
                chrome.storage.local.set({ 
                    'amazonProductData': response.data,
                    'amazonExtensionInstalled': 'true'
                });
                
            } else {
                throw new Error(response.message);
            }
            
        } catch (error) {
            console.error('提取失败:', error);
            showStatus(error.message || '提取失败，请重试', 'error');
        } finally {
            extractBtn.disabled = false;
            extractBtn.textContent = '提取产品信息';
        }
    });
    
    // 复制按钮点击事件
    // 复制按钮点击事件
    copyBtn.addEventListener('click', async function() {
        try {
            const result = await chrome.storage.local.get(['amazonProductData']);
            if (result.amazonProductData) {
                copyProductInfo(result.amazonProductData);
            }
        } catch (error) {
            console.error('复制失败:', error);
        }
    });
    
    // 打开计算器
    openCalculatorBtn.addEventListener('click', async function() {
        try {
            // 获取存储的产品数据
            const result = await chrome.storage.local.get(['amazonProductData']);
            
            // 数据已经在chrome.storage中，无需额外操作
            
            // 直接跳转到amzailisting.com的利润计算器页面
            const calculatorUrl = 'https://amzailisting.com/amazon_profit_calculator.html';
            chrome.tabs.create({ url: calculatorUrl });
            window.close();
        } catch (error) {
            console.error('打开计算器失败:', error);
            showStatus('打开计算器失败', 'error');
        }
    });
    
    // 检查是否有之前提取的数据
    chrome.storage.local.get(['amazonProductData', 'extractTime'], function(result) {
        if (result.amazonProductData && result.extractTime) {
            // 如果数据是最近5分钟内的，显示它
            const fiveMinutesAgo = Date.now() - (5 * 60 * 1000);
            if (result.extractTime > fiveMinutesAgo) {
                showProductInfo(result.amazonProductData);
                showStatus('显示最近提取的产品信息', 'info');
            }
        }
    });
});